 /**
 * Notes: 通用常量定义
 * Ver : modified by AI and me
 * Date: 2020-09-05 04:00:00 
 */
module.exports = {
 
}