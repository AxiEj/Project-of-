/**
 * Notes: 用户中心模块控制器
 * Date: 2021-03-15 19:20:00 
 */

const BaseController = require('./base_controller.js'); 
class MyController extends BaseController {
 

 

}

module.exports = MyController;