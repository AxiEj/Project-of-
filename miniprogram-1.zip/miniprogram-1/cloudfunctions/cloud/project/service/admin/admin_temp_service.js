/**
 * Notes: 预约后台管理
 * Ver : modified by AI and me
 * Date: 2021-12-08 07:48:00 
 */

const BaseAdminService = require('./base_admin_service.js');
const TempModel = require('../../model/temp_model.js');

class AdminTempService extends BaseAdminService {

	/**添加模板 */
	async insertTemp({
		name,
		times,
	}) {
		// 数据验证
		if (!name || !times) {
			this.AppError('模板名称和时间段不能为空');
		}

		// 构造插入数据
		let data = {
			TEMP_NAME: name,
			TEMP_TIMES: times,
			TEMP_ADD_TIME: this._timestamp,
			TEMP_EDIT_TIME: this._timestamp,
		};

		// 插入数据库
		let id = await TempModel.insert(data);
		
		return { id };
	}

	/**更新数据 */
	async editTemp({
		id,
		limit,
		isLimit
	}) {
		// 验证ID
		if (!id) {
			this.AppError('模板ID不能为空');
		}

		// 检查记录是否存在
		let temp = await TempModel.getOne(id);
		if (!temp) {
			this.AppError('模板不存在');
		}

		// 构造更新数据
		let data = {
			TEMP_EDIT_TIME: this._timestamp,
		};

		if (limit !== undefined) {
			data.TEMP_LIMIT = limit;
		}
		if (isLimit !== undefined) {
			data.TEMP_IS_LIMIT = isLimit;
		}

		// 更新数据库
		await TempModel.edit(id, data);
		
		return { msg: '更新成功' };
	}


	/**删除数据 */
	async delTemp(id) {
		// 验证ID
		if (!id) {
			this.AppError('模板ID不能为空');
		}

		// 检查记录是否存在
		let temp = await TempModel.getOne(id);
		if (!temp) {
			this.AppError('模板不存在');
		}

		// 删除数据
		await TempModel.del(id);
		
		return { msg: '删除成功' };
	}


	/**分页列表 */
	async getTempList() {
		let orderBy = {
			'TEMP_ADD_TIME': 'desc'
		};
		let fields = 'TEMP_NAME,TEMP_TIMES';

		let where = {};
		return await TempModel.getAll(where, fields, orderBy);
	}
}

module.exports = AdminTempService;
