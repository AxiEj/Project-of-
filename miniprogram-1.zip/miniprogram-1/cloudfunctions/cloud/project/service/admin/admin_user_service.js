/**
 * Notes: 用户管理
 * Ver : modified by AI and me
 * Date: 2022-01-22y 07:48:00 
 */
const BaseAdminService = require('./base_admin_service.js');
const util = require('../../../framework/utils/util.js');
const UserModel = require('../../model/user_model.js');
const JoinModel = require('../../model/join_model.js');

class AdminUserService extends BaseAdminService {

	/** 获得某个用户信息 */
	async getUser({
		userId,
		fields = '*'
	}) {
		let where = {
			USER_MINI_OPENID: userId,
		}
		return await UserModel.getOne(where, fields);
	}

	/** 取得用户分页列表 */
	async getUserList({
		search, // 搜索条件
		sortType, // 搜索菜单
		sortVal, // 搜索菜单
		orderBy, // 排序
		whereEx, //附加查询条件 
		page,
		size,
		oldTotal = 0
	}) {
		orderBy = orderBy || {
			USER_ADD_TIME: 'desc'
		};
		let fields = '*';

		let where = {};
		where.and = {
			_pid: this.getProjectId() //复杂的查询在此处标注PID
		};

		if (util.isDefined(search) && search) {
			where.or = [{
					USER_NAME: ['like', search]
				},
				{
					USER_MOBILE: ['like', search]
				},
				{
					USER_MEMO: ['like', search]
				},
			];
		} else if (sortType && util.isDefined(sortVal)) {
			// 搜索菜单
			switch (sortType) {
				case 'status':
					where.and.USER_STATUS = Number(sortVal);
					break;
				case 'companyDef':
					// 单位性质 
					where.and.USER_COMPANY_DEF = (sortVal);
					break;
				case 'sort':
					// 排序
					if (sortVal == 'newdesc') { //最新
						orderBy = {
							'USER_ADD_TIME': 'desc'
						};
					}
					if (sortVal == 'newasc') {
						orderBy = {
							'USER_ADD_TIME': 'asc'
						};
					}
			}
		}

		let result = await UserModel.getList(where, fields, orderBy, page, size, true, oldTotal, false);

		// 为导出增加一个参数condition
		result.condition = encodeURIComponent(JSON.stringify(where));

		return result;
	}

/**删除用户 */
async delUser(id) {
	// 检查用户是否存在
	let where = {
		_id: id
	};
	
	// 先不带 _pid 查询，确认用户是否存在
	let user = await UserModel.getOne(where);
	if (!user) {
		this.AppError('用户不存在');
	}

	// 验证用户是否属于当前项目
	if (user._pid !== this.getProjectId()) {
		this.AppError('无权限删除该用户');
	}

	// 删除用户相关的关联数据
	try {
		// 删除用户的报名记录
		await JoinModel.del({
			JOIN_USER_ID: user.USER_MINI_OPENID,
			_pid: this.getProjectId()
		});

		// 删除用户（只用 _id 作为条件）
		await UserModel.del({ _id: id });

		return { msg: '删除成功' };
	} catch (err) {
		console.error('删除用户失败:', err); // 添加日志便于排查
		this.AppError('删除失败：' + err.message);
	}
}

}

module.exports = AdminUserService;