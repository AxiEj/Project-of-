/**
 * Notes: 资讯后台管理
 * Ver : modified by AI and me
 * Date: 2021-07-11 07:48:00 
 */

const BaseAdminService = require('./base_admin_service.js');

const dataUtil = require('../../../framework/utils/data_util.js');
const util = require('../../../framework/utils/util.js');
const cloudUtil = require('../../../framework/cloud/cloud_util.js');

const NewsModel = require('../../model/news_model.js');

class AdminNewsService extends BaseAdminService {

	/**添加资讯 */
	async insertNews(adminId, {
		title,
		cateId, //分类
		cateName,
		order,
		type = 0, //类型 
		desc = '',
		url = '', //外部链接
	}) {
		// 数据校验
		if (!title) this.AppError('标题不能为空');
		if (!cateId) this.AppError('分类不能为空');

		// 构建数据对象
		let data = {
			NEWS_TITLE: title,
			NEWS_CATE_ID: cateId,
			NEWS_CATE_NAME: cateName,
			NEWS_ORDER: order || 9999,
			NEWS_TYPE: type,
			NEWS_DESC: desc,
			NEWS_URL: url,
			NEWS_ADMIN_ID: adminId,
			NEWS_ADD_TIME: this._timestamp,
			NEWS_EDIT_TIME: this._timestamp,
			NEWS_STATUS: 0, // 默认待审核
			NEWS_HOME: 0, // 默认不首页显示
			NEWS_VIEW_CNT: 0, // 浏览次数
			NEWS_CONTENT: [], // 富文本内容
			NEWS_PIC: [] // 图片列表
		};

		// 插入数据
		let id = await NewsModel.insert(data);
		
		return {
			id
		};
	}

	/**删除资讯数据 */
	async delNews(id) {
		// 检查资讯是否存在
		let where = {
			_id: id
		};
		let news = await NewsModel.getOne(where);
		if (!news) {
			this.AppError('资讯不存在');
		}

		// 删除图片文件
		if (news.NEWS_PIC && news.NEWS_PIC.length > 0) {
			for (let pic of news.NEWS_PIC) {
				try {
					await cloudUtil.deleteFile(pic.cloudId);
				} catch (err) {
					console.error('删除图片失败', err);
				}
			}
		}

		// 删除富文本中的图片
		if (news.NEWS_CONTENT && news.NEWS_CONTENT.length > 0) {
			for (let content of news.NEWS_CONTENT) {
				if (content.type === 'img' && content.cloudId) {
					try {
						await cloudUtil.deleteFile(content.cloudId);
					} catch (err) {
						console.error('删除内容图片失败', err);
					}
				}
			}
		}

		// 删除资讯记录
		await NewsModel.del(where);

		return {
			msg: '删除成功'
		};
	}

	/**获取资讯信息 */
	async getNewsDetail(id) {
		let fields = '*';

		let where = {
			_id: id
		}
		let news = await NewsModel.getOne(where, fields);
		if (!news) return null;

		return news;
	}

	/**
	 * 更新富文本详细的内容及图片信息
	 * @returns 返回 urls数组 [url1, url2, url3, ...]
	 */
	async updateNewsContent({
		newsId,
		content // 富文本数组
	}) {
		// 检查资讯是否存在
		let where = {
			_id: newsId
		};
		let news = await NewsModel.getOne(where);
		if (!news) {
			this.AppError('资讯不存在');
		}

		// 提取所有图片URL
		let urls = [];
		if (content && Array.isArray(content)) {
			for (let item of content) {
				if (item.type === 'img' && item.val) {
					urls.push(item.val);
				}
			}
		}

		// 更新数据
		let data = {
			NEWS_CONTENT: content,
			NEWS_EDIT_TIME: this._timestamp
		};

		await NewsModel.edit(where, data);

		return {
			urls
		};
	}

	/**
	 * 更新资讯图片信息
	 * @returns 返回 urls数组 [url1, url2, url3, ...]
	 */
	async updateNewsPic({
		newsId,
		imgList // 图片数组
	}) {
		// 检查资讯是否存在
		let where = {
			_id: newsId
		};
		let news = await NewsModel.getOne(where);
		if (!news) {
			this.AppError('资讯不存在');
		}

		// 提取所有图片URL
		let urls = [];
		if (imgList && Array.isArray(imgList)) {
			for (let img of imgList) {
				if (img.val) {
					urls.push(img.val);
				}
			}
		}

		// 更新数据
		let data = {
			NEWS_PIC: imgList,
			NEWS_EDIT_TIME: this._timestamp
		};

		await NewsModel.edit(where, data);

		return {
			urls
		};
	}


	/**更新资讯数据 */
	async editNews({
		id,
		title,
		cateId, //分类
		cateName,
		order,
		type = 0, //类型 
		desc = '',
		url = '', //外部链接
	}) {
		// 数据校验
		if (!title) this.AppError('标题不能为空');
		if (!cateId) this.AppError('分类不能为空');

		// 检查资讯是否存在
		let where = {
			_id: id
		};
		let news = await NewsModel.getOne(where);
		if (!news) {
			this.AppError('资讯不存在');
		}

		// 构建更新数据
		let data = {
			NEWS_TITLE: title,
			NEWS_CATE_ID: cateId,
			NEWS_CATE_NAME: cateName,
			NEWS_ORDER: order,
			NEWS_TYPE: type,
			NEWS_DESC: desc,
			NEWS_URL: url,
			NEWS_EDIT_TIME: this._timestamp
		};

		// 更新数据
		await NewsModel.edit(where, data);

		return {
			msg: '修改成功'
		};
	}

	/**取得资讯分页列表 */
	async getNewsList({
		search, // 搜索条件
		sortType, // 搜索菜单
		sortVal, // 搜索菜单
		orderBy, // 排序
		whereEx, //附加查询条件
		page,
		size,
		isTotal = true,
		oldTotal
	}) {

		orderBy = orderBy || {
			'NEWS_ORDER': 'asc',
			'NEWS_ADD_TIME': 'desc'
		};
		let fields = 'NEWS_TYPE,NEWS_URL,NEWS_TITLE,NEWS_DESC,NEWS_CATE_ID,NEWS_EDIT_TIME,NEWS_ADD_TIME,NEWS_ORDER,NEWS_STATUS,NEWS_CATE_NAME,NEWS_HOME';

		let where = {};

		if (util.isDefined(search) && search) {
			where.or = [{
				NEWS_TITLE: ['like', search]
			}, ];

		} else if (sortType && util.isDefined(sortVal)) {
			// 搜索菜单
			switch (sortType) {
				case 'cateId':
					// 按类型
					where.NEWS_CATE_ID = sortVal;
					break;
				case 'status':
					// 按类型
					where.NEWS_STATUS = Number(sortVal);
					break;
				case 'home':
					// 按类型
					where.NEWS_HOME = Number(sortVal);
					break;
				case 'sort':
					// 排序
					if (sortVal == 'view') {
						orderBy = {
							'NEWS_VIEW_CNT': 'desc',
							'NEWS_ADD_TIME': 'desc'
						};
					}
					if (sortVal == 'new') {
						orderBy = {
							'NEWS_ADD_TIME': 'desc'
						};
					}
					break;
			}
		}

		return await NewsModel.getList(where, fields, orderBy, page, size, isTotal, oldTotal);
	}

	/**修改资讯状态 */
	async statusNews(id, status) {
		// 检查资讯是否存在
		let where = {
			_id: id
		};
		let news = await NewsModel.getOne(where);
		if (!news) {
			this.AppError('资讯不存在');
		}

		// 更新状态
		let data = {
			NEWS_STATUS: status,
			NEWS_EDIT_TIME: this._timestamp
		};

		await NewsModel.edit(where, data);

		return {
			msg: '状态更新成功'
		};
	}

	/**资讯置顶排序设定 */
	async sortNews(id, sort) {
		// 检查资讯是否存在
		let where = {
			_id: id
		};
		let news = await NewsModel.getOne(where);
		if (!news) {
			this.AppError('资讯不存在');
		}

		// 更新排序
		let data = {
			NEWS_ORDER: sort,
			NEWS_EDIT_TIME: this._timestamp
		};

		await NewsModel.edit(where, data);

		return {
			msg: '排序更新成功'
		};
	}
}

module.exports = AdminNewsService;