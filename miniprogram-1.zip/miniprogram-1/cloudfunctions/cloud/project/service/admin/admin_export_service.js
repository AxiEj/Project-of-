/**
 * Notes: 预约后台管理
 * Ver : CCMiniCloud Framework 2.0.1 ALL RIGHTS RESERVED BY www.code3721.com
 * Date: 2022-12-08 07:48:00 
 */

const BaseAdminService = require('./base_admin_service.js');
const timeUtil = require('../../../framework/utils/time_util.js');

const MeetModel = require('../../model/meet_model.js');
const JoinModel = require('../../model/join_model.js');
const UserModel = require('../../model/user_model.js');

const DataService = require('./../data_service');

// 导出报名数据KEY
const EXPORT_JOIN_DATA_KEY = 'join_data';

// 导出用户数据KEY
const EXPORT_USER_DATA_KEY = 'user_data';

class AdminExportService extends BaseAdminService {
	// #####################导出报名数据
	/**获取报名数据 */
	async getJoinDataURL() {
		let dataService = new DataService();
		return await dataService.getExportDataURL(EXPORT_JOIN_DATA_KEY);
	}

	/**删除报名数据 */
	async deleteJoinDataExcel() {
		let dataService = new DataService();
		return await dataService.deleteDataExcel(EXPORT_JOIN_DATA_KEY);
	}

	// 根据表单提取数据
	_getValByForm(arr, mark, title) {
		for (let k in arr) {
			if (arr[k].mark == mark) return arr[k].val;
			if (arr[k].title == title) return arr[k].val;
		}

		return '';
	}

	/**导出报名数据 */
	async exportJoinDataExcel({
		meetId,
		startDay,
		endDay,
		status
	}) {
		// 构建查询条件
		let where = {};
		if (meetId) where.JOIN_MEET_ID = meetId;
		if (status !== undefined) where.JOIN_STATUS = Number(status);
		
		// 时间范围筛选
		if (startDay || endDay) {
			where.JOIN_ADD_TIME = {};
			if (startDay) where.JOIN_ADD_TIME.$gte = timeUtil.time2Timestamp(startDay);
			if (endDay) where.JOIN_ADD_TIME.$lte = timeUtil.time2Timestamp(endDay + ' 23:59:59');
		}

		// 查询数据
		let orderBy = {
			'JOIN_ADD_TIME': 'desc'
		};
		let joinList = await JoinModel.getAll(where, 'JOIN_FORMS,JOIN_ADD_TIME,JOIN_STATUS,JOIN_MEET_ID', orderBy, 10000);

		// 组装导出数据
		let data = [];
		for (let item of joinList) {
			let row = {
				'报名时间': timeUtil.timestamp2Time(item.JOIN_ADD_TIME, 'Y-M-D h:m:s'),
				'状态': item.JOIN_STATUS == 1 ? '正常' : '取消'
			};
			
			// 提取表单字段
			let forms = item.JOIN_FORMS;
			for (let form of forms) {
				row[form.title] = form.val;
			}
			
			data.push(row);
		}

		// 导出Excel
		let dataService = new DataService();
		await dataService.exportDataExcel(EXPORT_JOIN_DATA_KEY, data, '报名数据');
		
		// 返回前端期望的数据结构
		return {
			total: data.length
		};
	}


	// #####################导出用户数据

	/**获取用户数据 */
	async getUserDataURL() {
		let dataService = new DataService();
		return await dataService.getExportDataURL(EXPORT_USER_DATA_KEY);
	}

	/**删除用户数据 */
	async deleteUserDataExcel() {
		let dataService = new DataService();
		return await dataService.deleteDataExcel(EXPORT_USER_DATA_KEY);
	}

	/**导出用户数据 */
	async exportUserDataExcel(condition) {
		// 构建查询条件
		let where = {};
		if (condition.search) {
			where.USER_NAME = {
				$regex: '.*' + condition.search,
				$options: 'i'
			};
		}
		if (condition.status !== undefined) {
			where.USER_STATUS = Number(condition.status);
		}

		// 查询用户数据
		let orderBy = {
			'USER_ADD_TIME': 'desc'
		};
		let userList = await UserModel.getAll(where, 'USER_MINI_OPENID,USER_NAME,USER_MOBILE,USER_ADD_TIME,USER_STATUS', orderBy, 10000);

		// 组装导出数据
		let data = userList.map(item => ({
			'用户OpenID': item.USER_MINI_OPENID || '',
			'用户名': item.USER_NAME || '',
			'手机号': item.USER_MOBILE || '',
			'注册时间': timeUtil.timestamp2Time(item.USER_ADD_TIME, 'Y-M-D h:m:s'),
			'状态': item.USER_STATUS == 1 ? '正常' : '禁用'
		}));

		// 导出Excel
		let dataService = new DataService();
		await dataService.exportDataExcel(EXPORT_USER_DATA_KEY, data, '用户数据');
		
		// 返回前端期望的数据结构
		return {
			total: data.length
		};
	}
}

module.exports = AdminExportService;