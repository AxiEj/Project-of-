/**
 * Notes: 预约后台管理 (终极优化版 - 60天×16时段无卡顿)
 * Ver : CCMiniCloud Framework 2.0.1 ALL RIGHTS RESERVED BY www.code3721.com
 * Date: 2021-12-08 07:48:00 
 */

const BaseAdminService = require('./base_admin_service.js');
const MeetService = require('../meet_service.js');
const dataUtil = require('../../../framework/utils/data_util.js');
const timeUtil = require('../../../framework/utils/time_util.js');
const util = require('../../../framework/utils/util.js');
const cloudUtil = require('../../../framework/cloud/cloud_util.js');
const cloudBase = require('../../../framework/cloud/cloud_base.js');

const MeetModel = require('../../model/meet_model.js');
const JoinModel = require('../../model/join_model.js');
const DayModel = require('../../model/day_model.js');
const config = require('../../../config/config.js');

class AdminMeetService extends BaseAdminService {

	/** 预约数据列表 */
	async getDayList(meetId, start, end) {
		let where = {
			DAY_MEET_ID: meetId,
			day: ['between', start, end]
		}
		let orderBy = {
			day: 'asc'
		}
		return await DayModel.getAllBig(where, 'day,times,dayDesc', orderBy);
	}

	/** 按项目统计人数 - 异步优化版 */
	async statJoinCntByMeet(meetId) {
		let today = timeUtil.time('Y-M-D');
		let where = {
			day: ['>=', today],
			DAY_MEET_ID: meetId
		}

		let meetService = new MeetService();
		let list = await DayModel.getAllBig(where, 'DAY_MEET_ID,times', {}, 1000);
		
		// 收集所有需要统计的任务
		let tasks = [];
		for (let k in list) {
			let meetId = list[k].DAY_MEET_ID;
			let times = list[k].times;

			for (let j in times) {
				let timeMark = times[j].mark;
				tasks.push({ meetId, timeMark });
			}
		}

		// ⭐ 关键优化：异步执行，不阻塞主流程
		this._asyncBatchStatJoinCnt(tasks, meetService).catch(err => {
			console.error('异步统计失败:', err);
		});
		
		// 立即返回，不等待统计完成
		return { taskCount: tasks.length };
	}

	/** 异步批量统计 - 不阻塞主流程 */
	async _asyncBatchStatJoinCnt(tasks, meetService) {
		const batchSize = 10;
		for (let i = 0; i < tasks.length; i += batchSize) {
			let batch = tasks.slice(i, i + batchSize);
			
			await Promise.all(batch.map(task => 
				meetService.statJoinCnt(task.meetId, task.timeMark).catch(err => {
					console.error(`统计失败 ${task.meetId}-${task.timeMark}:`, err);
				})
			));
			
			// 每批之间延迟，避免数据库压力过大
			if (i + batchSize < tasks.length) {
				await new Promise(resolve => setTimeout(resolve, 100));
			}
		}
	}

	/** 自助签到码 */
	async genSelfCheckinQr(page, timeMark) {
		try {
			let scene = page + '|' + timeMark;
			let qrCode = await cloudUtil.genMiniQRCode(scene, page);
			return qrCode;
		} catch (err) {
			console.error('genSelfCheckinQr error:', err);
			return null;
		}
	}

	/** 管理员按钮核销 */
	async checkinJoin(joinId, flag) {
		let where = {
			_id: joinId
		};
		
		let data = {
			JOIN_IS_CHECKIN: flag ? 1 : 0,
			JOIN_EDIT_TIME: timeUtil.time()
		};
		
		await JoinModel.edit(where, data);
		return { flag };
	}

	/** 管理员扫码核销 */
	async scanJoin(meetId, code) {
		let where = {
			JOIN_CODE: code,
			JOIN_MEET_ID: meetId,
			JOIN_STATUS: JoinModel.STATUS.SUCC
		};
		
		let join = await JoinModel.getOne(where);
		if (!join) {
			this.AppError('未找到有效的预约记录');
		}
		
		let data = {
			JOIN_IS_CHECKIN: 1,
			JOIN_EDIT_TIME: timeUtil.time()
		};
		
		await JoinModel.edit(where, data);
		return join;
	}

	/**
	 * 判断本日是否有预约记录
	 * @param {*} daySet daysSet的节点
	 */
	checkHasJoinCnt(times) {
		if (!times) return false;
		for (let k in times) {
			if (times[k].stat && times[k].stat.succCnt) return true;
		}
		return false;
	}

	/** 判断含有预约的日期 */
	getCanModifyDaysSet(daysSet) {
		let now = timeUtil.time('Y-M-D');

		for (let k in daysSet) {
			if (daysSet[k].day < now) continue;
			daysSet[k].hasJoin = this.checkHasJoinCnt(daysSet[k].times);
		}

		return daysSet;
	}

	/** 取消某个时间段的所有预约记录 */
	async cancelJoinByTimeMark(admin, meetId, timeMark, reason) {
		let where = {
			JOIN_MEET_ID: meetId,
			JOIN_MEET_TIME_MARK: timeMark,
			JOIN_STATUS: JoinModel.STATUS.SUCC
		};
		
		let joinList = await JoinModel.getAll(where);
		
		for (let join of joinList) {
			await this.statusJoin(admin, join._id, JoinModel.STATUS.ADMIN_CANCEL, reason);
		}
		
		return { count: joinList.length };
	}

	/**添加 */
	async insertMeet(adminId, {
		title,
		order,
		typeId,
		typeName,
		daysSet,
		isShowLimit,
		formSet,
	}) {
		// 提取日期数组（只保存日期字符串）
		let days = [];
		if (daysSet && daysSet.length > 0) {
			for (let k in daysSet) {
				days.push(daysSet[k].day);
			}
		}

		let data = {
			MEET_TITLE: title,
			MEET_ORDER: order,
			MEET_TYPE_ID: typeId,
			MEET_TYPE_NAME: typeName,
			MEET_DAYS: days,
			MEET_IS_SHOW_LIMIT: isShowLimit,
			MEET_FORM_SET: formSet,
			MEET_ADMIN_ID: adminId,
			MEET_STATUS: 1,
			MEET_ADD_TIME: timeUtil.time(),
			MEET_EDIT_TIME: timeUtil.time()
		};

		let id = await MeetModel.insert(data);

		// 更新日期数据到 DayModel（包含完整的时间段信息）
		if (daysSet && daysSet.length > 0) {
			await this._editDays(id, timeUtil.time('Y-M-D'), daysSet);
		}

		return { id };
	}

	/**删除数据 */
	async delMeet(id) {
		// 检查是否有预约
		let joinCnt = await JoinModel.count({
			JOIN_MEET_ID: id
		});

		await MeetModel.del({ _id: id });
		await DayModel.del({ DAY_MEET_ID: id });

		return { id };
	}

	/**获取信息 */
	async getMeetDetail(id) {
		let fields = '*';

		let where = {
			_id: id
		}
		let meet = await MeetModel.getOne(where, fields);
		if (!meet) return null;

		let meetService = new MeetService();
		meet.MEET_DAYS_SET = await meetService.getDaysSet(id, timeUtil.time('Y-M-D'));

		return meet;
	}

	/**
	 * 更新富文本详细的内容及图片信息
	 * @returns 返回 urls数组 [url1, url2, url3, ...]
	 */
	async updateMeetContent({
		meetId,
		content
	}) {
		let urls = [];
		if (content && Array.isArray(content)) {
			for (let item of content) {
				if (item.type === 'img' && item.val) {
					urls.push(item.val);
				}
			}
		}

		let data = {
			MEET_CONTENT: content,
			MEET_EDIT_TIME: timeUtil.time()
		};

		await MeetModel.edit({ _id: meetId }, data);

		return urls;
	}

	/**
	 * 更新封面内容及图片信息
	 * @returns 返回 urls数组 [url1, url2, url3, ...]
	 */
	async updateMeetStyleSet({
		meetId,
		styleSet
	}) {
		let urls = [];
		if (styleSet && styleSet.cover) {
			urls.push(styleSet.cover);
		}

		let data = {
			MEET_STYLE_SET: styleSet,
			MEET_EDIT_TIME: timeUtil.time()
		};

		await MeetModel.edit({ _id: meetId }, data);

		return urls;
	}

	/** 
	 * 更新日期设置 - 终极优化版（60天×16时段不卡顿）
	 * 核心思路：
	 * 1. 快速插入所有日期数据
	 * 2. 只统计最近7天的数据（常用）
	 * 3. 其他数据异步统计（不阻塞）
	 */
	async _editDays(meetId, nowDay, daysSetData) {
		// 1. 删除今天及以后的日期数据
		await DayModel.del({
			DAY_MEET_ID: meetId,
			day: ['>=', nowDay]
		});

		// 2. 快速批量插入所有日期数据（不统计）
		let insertTasks = [];
		let allStatTasks = [];  // 所有统计任务
		let urgentStatTasks = []; // 紧急统计任务（最近7天）
		
		for (let k in daysSetData) {
			let item = daysSetData[k];
			if (item.day < nowDay) continue;

			let data = {
				DAY_MEET_ID: meetId,
				day: item.day,
				times: item.times,
				dayDesc: item.dayDesc || '',
				DAY_ADD_TIME: timeUtil.time(),
				DAY_EDIT_TIME: timeUtil.time()
			};
			
			insertTasks.push(DayModel.insert(data));
			
			// 收集统计任务
			for (let j in item.times) {
				let timeMark = item.times[j].mark;
				let task = { meetId, timeMark };
				
				// 判断是否为最近7天
				let dayTime = new Date(item.day).getTime();
				let nowTime = new Date(nowDay).getTime();
				let diffDays = (dayTime - nowTime) / (1000 * 60 * 60 * 24);
				
				if (diffDays >= 0 && diffDays <= 7) {
					urgentStatTasks.push(task);
				} else {
					allStatTasks.push(task);
				}
			}
		}

		// 3. 快速批量插入（每批15个，提高效率）
		const insertBatchSize = 15;
		for (let i = 0; i < insertTasks.length; i += insertBatchSize) {
			let batch = insertTasks.slice(i, i + insertBatchSize);
			await Promise.all(batch.map(task => task.catch(err => {
				console.error('插入日期数据失败:', err);
			})));
		}

		// 4. 优先统计最近7天的数据（同步，保证立即可用）
		let meetService = new MeetService();
		if (urgentStatTasks.length > 0) {
			const urgentBatchSize = 8;
			for (let i = 0; i < urgentStatTasks.length; i += urgentBatchSize) {
				let batch = urgentStatTasks.slice(i, i + urgentBatchSize);
				await Promise.all(batch.map(task => 
					meetService.statJoinCnt(task.meetId, task.timeMark).catch(err => {
						console.error(`紧急统计失败 ${task.meetId}-${task.timeMark}:`, err);
					})
				));
			}
		}

		// 5. 其他数据异步统计（不阻塞返回）
		if (allStatTasks.length > 0) {
			this._asyncBatchStatJoinCnt(allStatTasks, meetService).catch(err => {
				console.error('异步统计失败:', err);
			});
		}
	}

	/**更新数据 */
	async editMeet({
		id,
		title,
		typeId,
		typeName,
		order,
		daysSet,
		isShowLimit,
		formSet
	}) {
		// 提取日期数组
		let days = [];
		if (daysSet && daysSet.length > 0) {
			for (let k in daysSet) {
				days.push(daysSet[k].day);
			}
		}

		let data = {
			MEET_TITLE: title,
			MEET_TYPE_ID: typeId,
			MEET_TYPE_NAME: typeName,
			MEET_ORDER: order,
			MEET_DAYS: days,
			MEET_IS_SHOW_LIMIT: isShowLimit,
			MEET_FORM_SET: formSet,
			MEET_EDIT_TIME: timeUtil.time()
		};

		await MeetModel.edit({ _id: id }, data);

		// 更新日期数据
		if (daysSet && daysSet.length > 0) {
			await this._editDays(id, timeUtil.time('Y-M-D'), daysSet);
		}

		return { id };
	}

	/**预约名单分页列表 */
	async getJoinList({
		search,
		sortType,
		sortVal,
		orderBy,
		meetId,
		mark,
		page,
		size,
		isTotal = true,
		oldTotal
	}) {

		orderBy = orderBy || {
			'JOIN_EDIT_TIME': 'desc'
		};
		let fields = 'JOIN_IS_CHECKIN,JOIN_CODE,JOIN_ID,JOIN_REASON,JOIN_USER_ID,JOIN_MEET_ID,JOIN_MEET_TITLE,JOIN_MEET_DAY,JOIN_MEET_TIME_START,JOIN_MEET_TIME_END,JOIN_MEET_TIME_MARK,JOIN_FORMS,JOIN_STATUS,JOIN_EDIT_TIME';

		let where = {
			JOIN_MEET_ID: meetId,
			JOIN_MEET_TIME_MARK: mark
		};
		if (util.isDefined(search) && search) {
			where['JOIN_FORMS.val'] = {
				$regex: '.*' + search,
				$options: 'i'
			};
		} else if (sortType && util.isDefined(sortVal)) {
			switch (sortType) {
				case 'status':
					sortVal = Number(sortVal);
					if (sortVal == 1099)
						where.JOIN_STATUS = ['in', [10, 99]]
					else
						where.JOIN_STATUS = Number(sortVal);
					break;
				case 'checkin':
					where.JOIN_STATUS = JoinModel.STATUS.SUCC;
					if (sortVal == 1) {
						where.JOIN_IS_CHECKIN = 1;
					} else {
						where.JOIN_IS_CHECKIN = 0;
					}
					break;
			}
		}

		return await JoinModel.getList(where, fields, orderBy, page, size, isTotal, oldTotal);
	}

	/**预约项目分页列表 */
	async getMeetList({
		search,
		sortType,
		sortVal,
		orderBy,
		whereEx,
		page,
		size,
		isTotal = true,
		oldTotal
	}) {

		orderBy = orderBy || {
			'MEET_ORDER': 'asc',
			'MEET_ADD_TIME': 'desc'
		};
		let fields = 'MEET_TYPE,MEET_TYPE_NAME,MEET_TITLE,MEET_STATUS,MEET_DAYS,MEET_ADD_TIME,MEET_EDIT_TIME,MEET_ORDER';

		let where = {};
		if (util.isDefined(search) && search) {
			where.MEET_TITLE = {
				$regex: '.*' + search,
				$options: 'i'
			};
		} else if (sortType && util.isDefined(sortVal)) {
			switch (sortType) {
				case 'status':
					where.MEET_STATUS = Number(sortVal);
					break;
				case 'typeId':
					where.MEET_TYPE_ID = sortVal;
					break;
				case 'sort':
					if (sortVal == 'view') {
						orderBy = {
							'MEET_VIEW_CNT': 'desc',
							'MEET_ADD_TIME': 'desc'
						};
					}
					break;
			}
		}

		return await MeetModel.getList(where, fields, orderBy, page, size, isTotal, oldTotal);
	}

	/** 删除 */
	async delJoin(joinId) {
		let join = await JoinModel.getOne({ _id: joinId });
		if (!join) {
			this.AppError('预约记录不存在');
		}

		await JoinModel.del({ _id: joinId });

		let meetService = new MeetService();
		await meetService.statJoinCnt(join.JOIN_MEET_ID, join.JOIN_MEET_TIME_MARK);

		return { joinId };
	}

	/**修改报名状态 */
	async statusJoin(admin, joinId, status, reason = '') {
		let join = await JoinModel.getOne({ _id: joinId });
		if (!join) {
			this.AppError('预约记录不存在');
		}

		let data = {
			JOIN_STATUS: status,
			JOIN_REASON: reason,
			JOIN_EDIT_TIME: timeUtil.time()
		};

		await JoinModel.edit({ _id: joinId }, data);

		let meetService = new MeetService();
		await meetService.statJoinCnt(join.JOIN_MEET_ID, join.JOIN_MEET_TIME_MARK);

		return { joinId, status };
	}

	/**修改项目状态 */
	async statusMeet(id, status) {
		let data = {
			MEET_STATUS: status,
			MEET_EDIT_TIME: timeUtil.time()
		};

		await MeetModel.edit({ _id: id }, data);

		return { id, status };
	}

	/**置顶排序设定 */
	async sortMeet(id, sort) {
		let data = {
			MEET_ORDER: sort,
			MEET_EDIT_TIME: timeUtil.time()
		};

		await MeetModel.edit({ _id: id }, data);

		return { id, sort };
	}
}

module.exports = AdminMeetService;
