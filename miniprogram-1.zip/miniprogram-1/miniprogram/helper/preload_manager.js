/**
 * 预加载管理器 - 用于预加载预约详情数据
 * 用途：用户在列表浏览时后台预加载详情，提升打开速度
 */

const cloudHelper = require('./cloud_helper.js');

const PreloadManager = {
	// 内存缓存
	cache: new Map(),
	
	// 正在加载的ID集合
	loading: new Set(),
	
	// 配置
	config: {
		maxCache: 10,           // 最多缓存10个
		cacheTime: 5 * 60 * 1000, // 缓存5分钟
		preloadDelay: 300,      // 预加载延迟300ms
		useStorage: true,       // 是否使用本地存储
		storagePrefix: 'PRELOAD_MEET_' // 存储前缀
	},

	/**
	 * 预加载预约详情
	 * @param {String} meetId - 预约ID
	 * @param {Boolean} silent - 是否静默加载（不显示loading）
	 */
	async preloadDetail(meetId, silent = true) {
		if (!meetId) return;

		// 避免重复加载
		if (this.loading.has(meetId) || this.cache.has(meetId)) {
			console.log(`[预加载] ${meetId} 已在缓存或加载中，跳过`);
			return;
		}

		// 先检查本地存储
		if (this.config.useStorage) {
			const storageData = this._getFromStorage(meetId);
			if (storageData) {
				this.cache.set(meetId, {
					data: storageData,
					timestamp: Date.now()
				});
				console.log(`[预加载] ${meetId} 从本地存储加载`);
				return;
			}
		}

		this.loading.add(meetId);

		try {
			const params = { id: meetId };
			const opt = { 
				title: silent ? '' : 'bar',
				hideLoading: silent
			};

			console.log(`[预加载] 开始预加载 ${meetId}`);
			
			const meet = await cloudHelper.callCloudData('meet/view', params, opt);

			if (meet) {
				// 保存到内存缓存
				this.cache.set(meetId, {
					data: meet,
					timestamp: Date.now()
				});

				// 保存到本地存储
				if (this.config.useStorage) {
					this._saveToStorage(meetId, meet);
				}

				// 限制缓存数量
				this._limitCache();

				console.log(`[预加载] ✅ 成功预加载 ${meetId}`);
			}
		} catch (error) {
			console.warn(`[预加载] ❌ 预加载失败 ${meetId}:`, error);
		} finally {
			this.loading.delete(meetId);
		}
	},

	/**
	 * 批量预加载（用于列表加载完成后）
	 * @param {Array} meetIds - 预约ID数组
	 * @param {Number} count - 预加载数量
	 */
	preloadBatch(meetIds, count = 3) {
		if (!meetIds || meetIds.length === 0) return;

		const toPreload = meetIds.slice(0, count);
		
		toPreload.forEach((meetId, index) => {
			// 延迟预加载，避免阻塞主流程
			setTimeout(() => {
				this.preloadDetail(meetId, true);
			}, index * this.config.preloadDelay);
		});

		console.log(`[预加载] 批量预加载 ${toPreload.length} 个项目`);
	},

	/**
	 * 获取缓存的数据
	 * @param {String} meetId 
	 * @returns {Object|null}
	 */
	getCache(meetId) {
		if (!meetId) return null;

		// 先从内存获取
		const cached = this.cache.get(meetId);
		if (cached) {
			// 检查是否过期
			if (Date.now() - cached.timestamp > this.config.cacheTime) {
				this.cache.delete(meetId);
				console.log(`[预加载] ${meetId} 内存缓存已过期`);
			} else {
				console.log(`[预加载] ✅ 命中内存缓存 ${meetId}`);
				return cached.data;
			}
		}

		// 从本地存储获取
		if (this.config.useStorage) {
			const storageData = this._getFromStorage(meetId);
			if (storageData) {
				console.log(`[预加载] ✅ 命中本地缓存 ${meetId}`);
				// 同时放入内存缓存
				this.cache.set(meetId, {
					data: storageData,
					timestamp: Date.now()
				});
				return storageData;
			}
		}

		console.log(`[预加载] ❌ 未命中缓存 ${meetId}`);
		return null;
	},

	/**
	 * 清除缓存
	 * @param {String} meetId - 为空则清除所有
	 */
	clearCache(meetId) {
		if (meetId) {
			this.cache.delete(meetId);
			if (this.config.useStorage) {
				this._removeFromStorage(meetId);
			}
			console.log(`[预加载] 清除缓存 ${meetId}`);
		} else {
			this.cache.clear();
			if (this.config.useStorage) {
				this._clearAllStorage();
			}
			console.log('[预加载] 清除所有缓存');
		}
	},

	/**
	 * 限制缓存数量
	 */
	_limitCache() {
		if (this.cache.size > this.config.maxCache) {
			const firstKey = this.cache.keys().next().value;
			this.cache.delete(firstKey);
			if (this.config.useStorage) {
				this._removeFromStorage(firstKey);
			}
		}
	},

	/**
	 * 从本地存储获取
	 */
	_getFromStorage(meetId) {
		try {
			const key = this.config.storagePrefix + meetId;
			const cached = wx.getStorageSync(key);
			
			if (cached && cached.expire > Date.now()) {
				return cached.data;
			} else if (cached) {
				// 过期则删除
				wx.removeStorageSync(key);
			}
		} catch (e) {
			console.warn('[预加载] 本地存储读取失败', e);
		}
		return null;
	},

	/**
	 * 保存到本地存储
	 */
	_saveToStorage(meetId, data) {
		try {
			const key = this.config.storagePrefix + meetId;
			wx.setStorageSync(key, {
				data: data,
				expire: Date.now() + this.config.cacheTime
			});
		} catch (e) {
			console.warn('[预加载] 本地存储保存失败', e);
		}
	},

	/**
	 * 从本地存储删除
	 */
	_removeFromStorage(meetId) {
		try {
			const key = this.config.storagePrefix + meetId;
			wx.removeStorageSync(key);
		} catch (e) {
			console.warn('[预加载] 本地存储删除失败', e);
		}
	},

	/**
	 * 清空所有预加载的本地存储
	 */
	_clearAllStorage() {
		try {
			const res = wx.getStorageInfoSync();
			res.keys.forEach(key => {
				if (key.startsWith(this.config.storagePrefix)) {
					wx.removeStorageSync(key);
				}
			});
		} catch (e) {
			console.warn('[预加载] 清空本地存储失败', e);
		}
	},

	/**
	 * 获取缓存统计信息
	 */
	getStats() {
		return {
			memoryCache: this.cache.size,
			loading: this.loading.size,
			config: this.config
		};
	}
};

module.exports = {
	PreloadManager
};