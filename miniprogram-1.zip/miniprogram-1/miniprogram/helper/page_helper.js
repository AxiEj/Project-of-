/**
 * Notes: 通用页面操作类库 - 性能优化版
 * Ver : optimized for performance
 * Date: 2025-11-17
 * 
 * 优化点：
 * 1. 合并多次 setData 调用为单次批量更新
 * 2. 使用路径更新减少数据传输
 * 3. 添加防抖和节流机制
 * 4. 优化图片处理逻辑
 */

const helper = require('./helper.js');
const setting = require('../setting/setting.js');
const cacheHelper = require('./cache_helper.js');
const picHelper = require('./pic_helper.js');
const CACHE_SKIN = 'SKIN_PID';

// ============ 性能优化：批量 setData 管理器 ============
const setDataBatchManager = {
	timers: new WeakMap(),
	dataQueue: new WeakMap(),
	
	/**
	 * 批量更新 setData（合并多次调用）
	 * @param {*} that 页面实例
	 * @param {*} data 数据对象
	 * @param {*} immediate 是否立即执行
	 */
	batch(that, data, immediate = false) {
		if (!this.dataQueue.has(that)) {
			this.dataQueue.set(that, {});
		}
		
		const queue = this.dataQueue.get(that);
		Object.assign(queue, data);
		
		if (immediate) {
			this.flush(that);
			return;
		}
		
		// 使用微任务延迟执行，合并同一事件循环中的多次调用
		if (!this.timers.has(that)) {
			const timer = setTimeout(() => {
				this.flush(that);
			}, 0);
			this.timers.set(that, timer);
		}
	},
	
	flush(that) {
		const timer = this.timers.get(that);
		if (timer) {
			clearTimeout(timer);
			this.timers.delete(that);
		}
		
		const queue = this.dataQueue.get(that);
		if (queue && Object.keys(queue).length > 0) {
			that.setData(queue);
			this.dataQueue.set(that, {});
		}
	}
};

// ============ 性能优化：节流函数 ============
function throttle(fn, delay = 100) {
	let timer = null;
	let lastTime = 0;
	
	return function(...args) {
		const now = Date.now();
		if (now - lastTime < delay) {
			if (timer) clearTimeout(timer);
			timer = setTimeout(() => {
				lastTime = now;
				fn.apply(this, args);
			}, delay);
		} else {
			lastTime = now;
			fn.apply(this, args);
		}
	};
}

function getSkin() {
	return {
		PID: 'A00',
		NAV_COLOR: '#ffffff',
		NAV_BG: '#2858DF',
		MEET_NAME: '预约',
		MENU_ITEM: ['首页', '预约日历', '我的'],
		NEWS_CATE: '1=细胞间动态,2=小亮知识',
		MEET_TYPE: '1=请从下方的,2=预约日历进入',
		DEFAULT_FORMS: [{
			type: 'line',
			title: '姓名',
			desc: '请填写您的姓名',
			must: true,
			len: 50,
			onlySet: { mode: 'all', cnt: -1 },
			selectOptions: ['', ''],
			mobileTruth: true,
			checkBoxLimit: 2,
		}, {
			type: 'line',
			title: '手机',
			desc: '请填写您的手机号码',
			must: true,
			len: 50,
			onlySet: { mode: 'all', cnt: -1 },
			selectOptions: ['', ''],
			mobileTruth: true,
			checkBoxLimit: 2,
		}]
	}
}

function getCurrentPageURL() {
	const pages = getCurrentPages();
	const currentPage = pages[pages.length - 1];
	return `/${currentPage.route}`;
}

function setSkin(skin) {
	cacheHelper.set(CACHE_SKIN, skin, 86400 * 365);
}

function getPID() {
	if (setting.PID) return setting.PID;
	let route = getCurrentPageURL();

	if (route.includes('/admin/')) {
		let skin = getSkin();
		if (skin) return skin.PID;
	} else if (route.startsWith('/projects/A')) {
		let PID = route.replace('/projects/', '');
		PID = PID.split('/')[0];
		return PID;
	}
	return '';
}

function fmtURLByPID(url, PID = '') {
	if (!PID) PID = getPID();
	if (url.startsWith('/pages/')) {
		url = url.replace('/pages/', '/projects/' + PID + '/');
	} else {
		url = '/projects/' + PID + '/' + url;
	}
	return url;
}

function clearTimer(that, timerName = 'timer') {
	if (helper.isDefined(that.data[timerName])) {
		clearInterval(that.data[timerName]);
		setDataBatchManager.batch(that, { [timerName]: null });
	}
}

function getPrevPage(deep = 2) {
	let pages = getCurrentPages();
	return pages[pages.length - deep];
}

// ============ 性能优化：使用路径更新列表节点 ============
function modifyListNode(id, list, valName, val, idName = '_id') {
	if (!list || !Array.isArray(list)) return false;
	let pos = list.findIndex(item => item[idName] === id);
	if (pos > -1) {
		list[pos][valName] = val;
		return pos; // 返回索引位置，用于路径更新
	}
	return false;
}

/**
 * 【优化】使用路径更新，减少数据传输
 */
function modifyPrevPageListNode(id, valName, val, deep = 2, listName = 'dataList', idName = '_id') {
	let prevPage = getPrevPage(deep);
	if (!prevPage) return;

	let dataList = prevPage.data[listName];
	if (!dataList || !dataList.list) return;

	let pos = dataList.list.findIndex(item => item[idName] === id);
	if (pos > -1) {
		// ✅ 优化：使用路径更新，只更新变化的字段
		setDataBatchManager.batch(prevPage, {
			[`${listName}.list[${pos}].${valName}`]: val
		});
	}
}

/**
 * 【优化】批量更新多个字段
 */
function modifyPrevPageListNodeObject(id, vals, deep = 2, listName = 'dataList', idName = '_id') {
	let prevPage = getPrevPage(deep);
	if (!prevPage) return;

	let dataList = prevPage.data[listName];
	if (!dataList || !dataList.list) return;

	let pos = dataList.list.findIndex(item => item[idName] === id);
	if (pos > -1) {
		// ✅ 优化：合并为一次 setData
		const updates = {};
		for (let k in vals) {
			updates[`${listName}.list[${pos}].${k}`] = vals[k];
		}
		setDataBatchManager.batch(prevPage, updates);
	}
}

function delListNode(id, list, idName = '_id') {
	if (!list || !Array.isArray(list)) return false;
	let pos = list.findIndex(item => item[idName] === id);
	if (pos > -1) {
		list.splice(pos, 1);
		return true;
	}
	return false;
}

/**
 * 【优化】删除节点时合并 setData
 */
function delPrevPageListNode(id, deep = 2, listName = 'dataList', idName = '_id') {
	let prevPage = getPrevPage(deep);
	if (!prevPage) return;
	
	let dataList = prevPage.data[listName];
	if (!dataList) return;

	let list = dataList['list'];
	let total = dataList['total'] - 1;
	
	if (delListNode(id, list, idName)) {
		// ✅ 优化：合并为一次 setData
		setDataBatchManager.batch(prevPage, {
			[listName + '.list']: list,
			[listName + '.total']: total
		}, true);
	}
}

async function refreshPrevListNode(deep = 2, listName = 'dataList', listFunc = '_getList') {
	let prevPage = getPrevPage(deep);
	let dataList = prevPage.data[listName];
	if (!dataList) return;
	await prevPage[listFunc]();
}

/**
 * 【优化】使用节流避免频繁更新
 */
const scrollTop = throttle(function(e, that) {
	const shouldShow = e.scrollTop > 100;
	if (that.data.topShow !== shouldShow) {
		setDataBatchManager.batch(that, { topShow: shouldShow });
	}
}, 150);

// ============ 性能优化：图片操作 ============
/**
 * 【优化】图片选择 - 使用路径更新
 */
function chooseImage(that, max = 4, imgListName = 'imgList') {
	wx.chooseImage({
		count: max,
		sizeType: ['compressed'], // 强制压缩
		sourceType: ['album', 'camera'],
		success: async (res) => {
			const currentList = that.data[imgListName] || [];
			const newList = currentList.concat(res.tempFilePaths);
			
			// ✅ 一次性更新
			setDataBatchManager.batch(that, {
				[imgListName]: newList
			}, true);
		}
	});
}

/**
 * 【优化】删除图片 - 使用路径更新
 */
function delImage(that, idx, imgListName = 'imgList') {
	let callback = function () {
		const list = [...that.data[imgListName]];
		list.splice(idx, 1);
		setDataBatchManager.batch(that, {
			[imgListName]: list
		}, true);
	}
	showConfirm('确定要删除该图片吗？', callback);
}

function previewImage(that, url, imgListName = 'imgList') {
	wx.previewImage({
		urls: that.data[imgListName],
		current: url
	});
}

function dataset(e, name, child = false) {
	if (!child)
		return e.currentTarget.dataset[name];
	else
		return e.target.dataset[name];
}

/**
 * 【优化】表单双向绑定
 */
function model(that, e) {
	let item = e.currentTarget.dataset.item;
	setDataBatchManager.batch(that, {
		[item]: e.detail.value
	});
}

/**
 * 【优化】开关按钮绑定
 */
function switchModel(that, e, mode = 'int') {
	let item = e.currentTarget.dataset.item;
	let sel = (e.detail.value) ? 1 : 0;

	if (mode == 'bool') {
		sel = (e.detail.value) ? true : false;
	}

	setDataBatchManager.batch(that, {
		[item]: sel
	});
}

// ============ Toast 提示优化（保持原有逻辑）============
function showNoneToast(title = '操作完成', duration = 1500, callback) {
	return wx.showToast({
		title: title,
		icon: 'none',
		duration: duration,
		mask: true,
		success: function () {
			callback && (setTimeout(() => {
				callback();
			}, duration));
		}
	});
}

function showNoneToastReturn(title = '操作完成', duration = 2000) {
	let callback = function () {
		wx.navigateBack({ delta: 0 });
	}
	return showNoneToast(title, duration, callback);
}

function showErrToast(title = '操作失败', duration = 1500, callback) {
	return wx.showToast({
		title: title,
		icon: 'error',
		duration: duration,
		mask: true,
		success: function () {
			callback && (setTimeout(() => {
				callback();
			}, duration));
		}
	});
}

function showLoadingToast(title = '加载中', duration = 1500, callback) {
	return wx.showToast({
		title: title,
		icon: 'loading',
		duration: duration,
		mask: true,
		success: function () {
			callback && (setTimeout(() => {
				callback();
			}, duration));
		}
	});
}

function showSuccToast(title = '操作成功', duration = 1500, callback) {
	return wx.showToast({
		title: title,
		icon: 'success',
		duration: duration,
		mask: true,
		success: function () {
			callback && (setTimeout(() => {
				callback();
			}, duration));
		}
	});
}

function showSuccToastReturn(title = '操作成功', duration = 1500) {
	let callback = function () {
		wx.navigateBack({ delta: 0 });
	}
	return showSuccToast(title, duration, callback);
}

/**
 * 【优化】清理表单焦点 - 批量更新
 */
function formClearFocus(that) {
	let data = that.data;
	let focus = {};
	for (let key in data) {
		if (key.startsWith('form') && !key.endsWith('Focus'))
			focus[key + 'Focus'] = null;
	}
	if (Object.keys(focus).length > 0) {
		setDataBatchManager.batch(that, focus, true);
	}
}

function formHint(that, formName, hint) {
	setDataBatchManager.batch(that, {
		[formName + 'Focus']: hint
	});
	return showModal(hint);
}

function formSetBarTitleByAddEdit(id, title) {
	title = id ? title + '编辑' : title + '添加';
	wx.setNavigationBarTitle({ title });
}

function showConfirm(title = '确定要删除吗？', yes, no) {
	return wx.showModal({
		title: '',
		content: title,
		cancelText: '取消',
		confirmText: '确定',
		success: res => {
			if (res.confirm) {
				yes && yes();
			} else if (res.cancel) {
				no && no();
			}
		}
	})
}

function showModal(content, title = '温馨提示', callback = null, confirmText = null) {
	return wx.showModal({
		title,
		content: content,
		confirmText: confirmText || '确定',
		showCancel: false,
		success(res) {
			callback && callback();
		}
	});
}

/**
 * 【优化】页面赋值 - 过滤保留字段
 */
function setPageData(that, data) {
	if (helper.isDefined(data['__webviewId__']))
		delete data['__webviewId__'];

	// ✅ 批量更新
	setDataBatchManager.batch(that, data, true);
}

/**
 * 【优化】列表监听器 - 合并更新
 */
function commListListener(that, e) {
	const updates = {};
	
	if (helper.isDefined(e.detail.search)) {
		updates.search = '';
		updates.sortType = '';
	} else {
		updates.dataList = e.detail.dataList;
		if (e.detail.sortType) {
			updates.sortType = e.detail.sortType;
		}
	}
	
	setDataBatchManager.batch(that, updates, true);
}

function bindShowModalTap(e) {
	setDataBatchManager.batch(this, {
		modalName: e.currentTarget.dataset.modal
	});
}

function bindHideModalTap(e) {
	setDataBatchManager.batch(this, {
		modalName: null
	});
}

/**
 * 【优化】显示回顶按钮 - 使用节流
 */
const showTopBtn = throttle(function(e, that) {
	const shouldShow = e.scrollTop > 100;
	if (that.data.topBtnShow !== shouldShow) {
		setDataBatchManager.batch(that, { topBtnShow: shouldShow });
	}
}, 150);

function top() {
	wx.pageScrollTo({ scrollTop: 0 });
}

function anchor(id, that) {
	let query = wx.createSelectorQuery().in(that);
	query.selectViewport().scrollOffset();
	query.select('#' + id).boundingClientRect();

	query.exec(function (res) {
		if (!res || res.length != 2 || !res[0] || !res[1]) return;
		let miss = res[0].scrollTop + res[1].top - 10;
		wx.pageScrollTo({
			scrollTop: miss,
			duration: 300
		});
	});
}

function url(e, that) {
	let url = e.currentTarget.dataset.url;
	let type = e.currentTarget.dataset.type;
	if (!type) type = 'url';

	switch (type) {
		case 'picker': {
			let item = e.currentTarget.dataset.item;
			setDataBatchManager.batch(that, {
				[item]: e.detail
			});
			break;
		}
		case 'map':
		case 'location': {
			wx.getLocation({
				type: 'gcj02',
				success(res) {
					if (url) res = url;
					const { latitude, longitude, name, address } = res;
					wx.openLocation({
						latitude,
						longitude,
						name,
						address,
						scale: 14
					});
				}
			});
			break;
		}
		case 'top': {
			top();
			break;
		}
		case 'mini': {
			wx.navigateToMiniProgram({
				appId: e.currentTarget.dataset.app,
				path: url,
				envVersion: 'release'
			});
			break;
		}
		case 'out': {
			wx.navigateTo({
				url: fmtURLByPID('/pages/public/web_article?url=' + encodeURIComponent(url)),
			});
			break;
		}
		case 'redirect': {
			if (!url) return;
			wx.redirectTo({ url });
			break;
		}
		case 'reLaunch':
		case 'relaunch': {
			if (!url) return;
			wx.reLaunch({ url });
			break;
		}
		case 'copy': {
			wx.setClipboardData({
				data: url,
				success(res) {
					wx.getClipboardData({
						success(res) {
							showNoneToast('已复制到剪贴板');
						}
					});
				}
			});
			break;
		}
		case 'hint': {
			if (!url) return;
			showModal(url);
			break;
		}
		case 'switch': {
			if (!url) return;
			wx.switchTab({ url });
			break;
		}
		case 'back': {
			wx.navigateBack({ delta: 0 });
			break;
		}
		case 'toURL': {
			toURL(url);
			break;
		}
		case 'phone': {
			wx.makePhoneCall({ phoneNumber: url });
			break;
		}
		case 'anchor': {
			anchor(url, that);
			break;
		}
		case 'saveimg':
		case 'saveimage': {
			let callback = function () {
				wx.saveImageToPhotosAlbum({
					filePath: url,
					success: function (res) {
						wx.showToast({
							title: e.currentTarget.dataset.hint || '保存成功',
							icon: 'none',
							duration: 2000
						});
					},
					fail: function (err) {
						console.error(err);
					}
				});
			}
			picHelper.getWritePhotosAlbum(callback);
			break;
		}
		case 'bool': {
			setDataBatchManager.batch(that, {
				[url]: !that.data[url]
			});
			break;
		}
		case 'img':
		case 'image': {
			if (url.indexOf('qlogo') > -1) {
				url = url.replace('/132', '/0');
			}
			let urls = [url];
			if (helper.isDefined(e.currentTarget.dataset.imgs))
				urls = e.currentTarget.dataset.imgs;

			wx.previewImage({
				current: url,
				urls
			});
			break;
		}
		default:
			if (!url) return;
			wx.navigateTo({ url });
	}
}

function getOptions(that, options, idName = 'id') {
	let id = options[idName];
	if (!id) return false;

	setDataBatchManager.batch(that, {
		[idName]: id
	}, true);
	return true;
}

function hint(msg, type = 'redirect') {
	if (type == 'reLaunch')
		wx.reLaunch({
			url: fmtURLByPID('/pages/public/hint?type=9&msg=' + encodeURIComponent(msg)),
		});
	else
		wx.redirectTo({
			url: fmtURLByPID('/pages/public/hint?type=9&msg=' + encodeURIComponent(msg)),
		});
}

function toURL(url) {
	let pages = getCurrentPages();
	for (let k in pages) {
		if (pages[k].route.includes(url)) {
			wx.navigateBack({
				delta: pages.length - k - 1
			});
			return;
		}
	}
	wx.redirectTo({ url });
}

/**
 * 【优化】触摸事件 - 合并更新
 */
function listTouchStart(e, that) {
	setDataBatchManager.batch(that, {
		touchX: e.touches[0].pageX
	});
}

function listTouchMove(e, that, precision = 50) {
	const diff = that.data.touchX - e.touches[0].pageX;
	const direction = diff > precision ? 'left' : (diff < -precision ? 'right' : null);
	
	if (direction && that.data.touchDirection !== direction) {
		setDataBatchManager.batch(that, { touchDirection: direction });
	}
}

function listTouchEnd(e, that) {
	const updates = { touchDirection: null };
	
	if (that.data.touchDirection == 'left') {
		updates.touchCur = e.currentTarget.dataset.idx;
	} else {
		updates.touchCur = null;
	}
	
	setDataBatchManager.batch(that, updates);
}

/**
 * 【优化】多条件查询 - 批量更新
 */
function queryMulti(that, e, key, val, def) {
	key = helper.isDefined(key) ? key : dataset(e, 'key');
	val = helper.isDefined(val) ? val : dataset(e, 'val');
	def = helper.isDefined(def) ? def : dataset(e, 'def');

	if (def == 'int') {
		val = parseInt(val);
	} else if (def == 'float') {
		val = parseFloat(val);
	} else if (def == 'str') {
		val = val.toString();
	}

	let _params = that.data._params;
	_params.query[key] = val;
	
	setDataBatchManager.batch(that, { _params });
}

// 缓存相关（保持原逻辑）
function cacheListExist(key, that, listKey = 'list') {
	key = key.toUpperCase();
	if (setting.CACHE_IS_LIST)
		return cacheHelper.get(key + '_LIST') && that.data && that.data[listKey];
	else
		return false;
}

function cacheListRemove(key) {
	key = key.toUpperCase();
	if (setting.CACHE_IS_LIST)
		cacheHelper.remove(key + '_LIST');
}

function cacheListSet(key, time = setting.CACHE_LIST_TIME) {
	key = key.toUpperCase();
	if (setting.CACHE_IS_LIST)
		cacheHelper.set(key + '_LIST', 'TRUE', time);
}

module.exports = {
	setSkin,
	getSkin,
	getPID,
	fmtURLByPID,

	// 表单
	formClearFocus,
	formHint,
	formSetBarTitleByAddEdit,

	// 节点
	dataset,

	// 节点操作
	getPrevPage,
	modifyListNode,
	modifyPrevPageListNode,
	modifyPrevPageListNodeObject,
	delListNode,
	delPrevPageListNode,
	refreshPrevListNode,

	scrollTop,

	// 图片
	chooseImage,
	previewImage,
	delImage,

	// 提示窗口
	showSuccToastReturn,
	showSuccToast,
	showErrToast,
	showNoneToast,
	showNoneToastReturn,
	showLoadingToast,
	showConfirm,
	showModal,
	setPageData,

	hint,

	commListListener,

	bindShowModalTap,
	bindHideModalTap,
	showTopBtn,

	getOptions,

	model,
	switchModel,

	top,
	url,
	anchor,

	toURL,

	// 列表横向滑动
	listTouchStart,
	listTouchMove,
	listTouchEnd,

	// 多条件复合查询
	queryMulti,

	clearTimer,

	// LIST数据缓存
	cacheListExist,
	cacheListRemove,
	cacheListSet,

	// ✅ 新增：暴露批量更新管理器（供其他模块使用）
	setDataBatch: setDataBatchManager.batch.bind(setDataBatchManager),
	setDataFlush: setDataBatchManager.flush.bind(setDataBatchManager),
}