let behavior = require('../../../../behavior/default_index_bh.js');
let PassortBiz = require('../../../../biz/passport_biz.js');
let skin = require('../../skin/skin.js');

Page({
	behaviors: [behavior],

	data: {
		isImgLoaded: false, // 图片加载状态
		showSkeleton: true, // 骨架屏显示状态
	},

	onLoad: function(options) {
		// 预加载关键图片
		this.preloadImages();
		
		// 提前初始化数据
		this.setData({
			skin: skin,
			isProfile: false
		});
	},

	onReady: function() {
		// 延迟初始化非关键内容
		wx.nextTick(() => {
			PassortBiz.initPage({
				skin,
				that: this,
				isLoadSkin: true,
				tabIndex: -1,
				isModifyNavColor: true
			});
		});

		// 隐藏骨架屏
		setTimeout(() => {
			this.setData({
				showSkeleton: false
			});
		}, 300);
	},

	// 预加载图片
	preloadImages: function() {
		const imgList = [
			'../../skin/images/default_index_bg.jpg',
			'https://i.postimg.cc/JhpsR5C9/image.png',
			'https://i.postimg.cc/L8bdRJ0r/image.png',
			'https://i.postimg.cc/bJPmj8pf/image.png',
			'https://i.postimg.cc/cLZMDW73/image.png'
		];

		// 使用 Promise.all 并行加载
		Promise.all(
			imgList.map(src => {
				return new Promise((resolve) => {
					wx.getImageInfo({
						src: src,
						success: () => resolve(),
						fail: () => resolve() // 失败也继续
					});
				});
			})
		).then(() => {
			this.setData({
				isImgLoaded: true
			});
		});
	},

	// 图片加载完成回调
	onImageLoad: function(e) {
		// 可以在这里添加淡入动画等效果
		console.log('图片加载完成');
	},

	// 图片加载失败回调
	onImageError: function(e) {
		console.error('图片加载失败', e);
		// 可以设置默认图片
	}
})