const MeetBiz = require('../biz/meet_biz.js');
const pageHelper = require('../helper/page_helper.js');
const cloudHelper = require('../helper/cloud_helper.js');

module.exports = Behavior({

	/**
	 * 页面的初始数据
	 */
	data: {
		// 预定义常量数据，避免重复创建
		sortItems: null,
		sortMenus: null
	},

	methods: {
		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function (options) {
		},

		/**
		 * 生命周期函数--监听页面初次渲染完成
		 */
		onReady: function () {

		},

		/**
		 * 生命周期函数--监听页面显示
		 */
		onShow: function () {

		},

		/**
		 * 生命周期函数--监听页面隐藏
		 */
		onHide: function () {

		},

		/**
		 * 生命周期函数--监听页面卸载
		 */
		onUnload: function () {

		},

		/**
		 * 页面相关事件处理函数--监听用户下拉动作
		 */
		onPullDownRefresh: function () {

		},

		/**
		 * 页面上拉触底事件的处理函数
		 */
		onReachBottom: function () {

		},

		/**
		 * 用户点击右上角分享
		 */
		onShareAppMessage: function () {

		},

		url: function (e) {
			pageHelper.url(e, this);
		},

		bindCommListCmpt: function (e) {
			pageHelper.commListListener(this, e);
		},

		/** 搜索菜单设置 - 优化：减少重复设置，使用缓存 */
		getSearchMenu: function (skin, that) {
			// 优化1：如果已经设置过菜单，不重复设置
			if (that.data.sortItems && that.data.sortMenus) {
				return;
			}

			wx.setNavigationBarTitle({
				title: '我的' + skin.MEET_NAME
			});

			// 优化2：使用更简洁的数据结构
			const sortItems = [
				[
					{ label: '排序', type: '', value: '' },
					{ label: '按时间倒序', type: 'timedesc', value: '' },
					{ label: '按时间正序', type: 'timeasc', value: '' }
				]
			];

			const sortMenus = [
				{ label: '全部', type: '', value: '' },
				{ label: '今日', type: 'today', value: '' },
				{ label: '明日', type: 'tomorrow', value: '' },
				{ label: '已预约', type: 'succ', value: '' },
				{ label: '已取消', type: 'cancel', value: '' }
			];

			// 优化3：一次性 setData，减少渲染次数
			that.setData({
				sortItems,
				sortMenus
			});
		},

		bindCancelTap: function (e) {
			const that = this;
			const joinId = pageHelper.dataset(e, 'id');

			const callback = async () => {
				try {
					const params = { joinId };
					const opts = { title: '取消中' };

					await cloudHelper.callCloudSumbit('my/my_join_cancel', params, opts);
					
					// 优化4：直接修改数据后一次性 setData，避免中间状态
					const dataList = that.data.dataList;
					pageHelper.modifyListNode(joinId, dataList.list, 'JOIN_STATUS', 10, '_id');
					
					// 优化5：只更新必要的数据路径
					that.setData({
						'dataList.list': dataList.list
					});
					
					pageHelper.showNoneToast('已取消');
				} catch (err) {
					console.error('取消预约失败:', err);
					pageHelper.showModal('取消失败，请重试');
				}
			};

			pageHelper.showConfirm('确认取消该预约?', callback);
		}
	}
})