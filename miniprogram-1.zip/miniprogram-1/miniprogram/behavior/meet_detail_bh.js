const cloudHelper = require('../helper/cloud_helper.js');
const pageHelper = require('../helper/page_helper.js');
const AdminMeetBiz = require('../biz/admin_meet_biz.js');
const MeetBiz = require('../biz/meet_biz.js');
const setting = require('../setting/setting.js');
const { PreloadManager } = require('../helper/preload_manager.js');

module.exports = Behavior({

	/**
	 * 页面的初始数据
	 */
	data: {
		isLoad: false,

		tabCur: 0,
		mainCur: 0,
		verticalNavTop: 0,

		showMind: true,
		showTime: false,
		
		// 缓存DOM位置信息
		tabHeightCache: [],
		lastScrollTime: 0,
		
		// 🔥 分页加载配置（可选）
		loadedDays: 7,
		totalDays: 0,
		allDaysData: [],
		isLoadingMore: false,
		hasMoreDays: true,
	},
	methods: {
		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function (options) {
			if (!pageHelper.getOptions(this, options)) return;

			this._loadDetail();
		},

		_loadDetail: async function () {
			let id = this.data.id;
			if (!id) return;

			// 🔥 关键优化：先尝试从预加载缓存获取
			let meet = PreloadManager.getCache(id);
			
			if (meet) {
				console.log('[详情页] ✅ 使用预加载数据，秒开！');
				
				// 立即显示预加载的数据
				this._processMeetData(meet, true);
				
				// 🔥 后台静默刷新最新数据
				setTimeout(() => {
					this._refreshInBackground(id);
				}, 500);
				
			} else {
				console.log('[详情页] 缓存未命中，正常加载');
				
				// 正常加载流程
				let params = { id };
				let opt = { title: 'bar' };
				meet = await cloudHelper.callCloudData('meet/view', params, opt);
				
				if (!meet) {
					this.setData({ isLoad: null });
					return;
				}
				
				this._processMeetData(meet, false);
			}
		},

		/**
		 * 🔥 后台静默刷新数据
		 */
		async _refreshInBackground(id) {
			try {
				let params = { id };
				let opt = { title: '', hideLoading: true };
				let meet = await cloudHelper.callCloudData('meet/view', params, opt);
				
				if (meet) {
					console.log('[详情页] 后台刷新完成');
					this._processMeetData(meet, false);
					
					// 更新预加载缓存
					PreloadManager.clearCache(id);
				}
			} catch (e) {
				console.warn('[详情页] 后台刷新失败', e);
			}
		},

		/**
		 * 🔥 处理预约数据（统一处理逻辑）
		 */
		_processMeetData(meet, isFromCache) {
			// 预处理数据
			if (meet.MEET_DAYS_SET && meet.MEET_DAYS_SET.length > 0) {
				meet.MEET_DAYS_SET.forEach(day => {
					if (day.times && day.times.length > 0) {
						day.times.forEach(time => {
							// 提前计算好显示文本
							if (time.error) {
								time.displayText = `(${time.error})`;
							} else if (meet.MEET_IS_SHOW_LIMIT == 1 && time.isLimit) {
								time.displayText = `(${time.stat.succCnt}/${time.limit})`;
							} else if (meet.MEET_IS_SHOW_LIMIT == 1 && !time.isLimit) {
								time.displayText = '(人数不限)';
							} else {
								time.displayText = '(可预约)';
							}
						});
					}
				});
			}

			// 🔥 可选：分页加载（如果天数很多）
			const allDaysData = meet.MEET_DAYS_SET || [];
			const totalDays = allDaysData.length;
			const loadedDays = Math.min(this.data.loadedDays, totalDays);
			const displayDays = allDaysData.slice(0, loadedDays);

			this.setData({
				isLoad: true,
				meet: {
					...meet,
					MEET_DAYS_SET: displayDays
				},
				allDaysData: allDaysData,
				totalDays: totalDays,
				loadedDays: loadedDays,
				hasMoreDays: loadedDays < totalDays,
				canNullTime: setting.MEET_CAN_NULL_TIME
			});
			
			// 计算DOM位置
			if (!isFromCache) {
				this._calculateTabHeights();
			} else {
				// 缓存数据也需要计算，但延迟执行
				setTimeout(() => {
					this._calculateTabHeights();
				}, 100);
			}
		},

		/**
		 * 🔥 加载更多天数（分页加载）
		 */
		_loadMoreDays: function() {
			if (this.data.isLoadingMore || !this.data.hasMoreDays) return;
			
			this.setData({ isLoadingMore: true });
			
			const currentLoaded = this.data.loadedDays;
			const batchSize = 7;
			const newLoaded = Math.min(currentLoaded + batchSize, this.data.totalDays);
			const displayDays = this.data.allDaysData.slice(0, newLoaded);
			
			setTimeout(() => {
				this.setData({
					'meet.MEET_DAYS_SET': displayDays,
					loadedDays: newLoaded,
					hasMoreDays: newLoaded < this.data.totalDays,
					isLoadingMore: false
				}, () => {
					this._calculateTabHeights();
				});
			}, 100);
		},
		
		// 计算并缓存各个tab的高度
		_calculateTabHeights: function() {
			const that = this;
			
			setTimeout(() => {
				const list = this.data.meet.MEET_DAYS_SET;
				if (!list || list.length === 0) return;
				
				let tabHeightCache = [];
				let queries = [];
				
				const query = wx.createSelectorQuery().in(this);
				for (let i = 0; i < list.length; i++) {
					queries.push(
						query.select("#main-" + i).boundingClientRect()
					);
				}
				
				query.exec((res) => {
					let totalHeight = 0;
					res.forEach((rect, i) => {
						if (rect) {
							tabHeightCache[i] = {
								top: totalHeight,
								bottom: totalHeight + rect.height,
								height: rect.height
							};
							totalHeight += rect.height;
						}
					});
					
					that.setData({
						tabHeightCache: tabHeightCache
					});
				});
			}, 300);
		},

		onReady: function () {

		},

		onShow: function () {

		},

		onHide: function () {

		},

		onUnload: function () {
			// 🔥 页面卸载时，如果数据是从缓存来的，清除缓存
			// 确保下次进入时能获取最新数据
			if (this.data.id) {
				PreloadManager.clearCache(this.data.id);
			}
		},

		onPullDownRefresh: async function () {
			// 🔥 清除预加载缓存
			if (this.data.id) {
				PreloadManager.clearCache(this.data.id);
			}
			
			await this._loadDetail();
			wx.stopPullDownRefresh();
		},

		onReachBottom: function () {
			// 🔥 触底加载更多天数
			if (this.data.showTime && this.data.hasMoreDays) {
				this._loadMoreDays();
			}
		},

		onShareAppMessage: function () {

		},

		bindJoinTap: async function (e) {
			let dayIdx = pageHelper.dataset(e, 'dayidx');
			let timeIdx = pageHelper.dataset(e, 'timeidx');

			let time = this.data.meet.MEET_DAYS_SET[dayIdx].times[timeIdx];

			if (time.error) {
				if (time.error.includes('预约'))
					return pageHelper.showModal('该时段' + time.error + '，换一个时段试试吧！');
				else
					return pageHelper.showModal('该时段预约' + time.error + '，换一个时段试试吧！');
			}

			let meetId = this.data.id;
			let timeMark = time.mark;

			let callback = async () => {
				try {
					let opts = {
						title: '请稍候',
					}
					let params = {
						meetId,
						timeMark
					}
					await cloudHelper.callCloudSumbit('meet/before_join', params, opts).then(res => {
						wx.navigateTo({
							url: `../join/meet_join?id=${meetId}&timeMark=${timeMark}`,
						})
					});
				} catch (ex) {
					console.log(ex);
				}
			}
			MeetBiz.subscribeMessageMeet(callback);
		},

		url: function (e) {
			pageHelper.url(e, this);
		},

		onPageScroll: function (e) {
			const now = Date.now();
			if (now - this.data.lastScrollTime < 150) return;
			
			const shouldShow = e.scrollTop > 100;
			if (this.data.topShow !== shouldShow) {
				this.setData({
					topShow: shouldShow,
					lastScrollTime: now
				});
			}
		},

		bindTopTap: function () {
			wx.pageScrollTo({
				scrollTop: 0,
				duration: 300
			})
		},

		bindVerticalMainScroll: function (e) {
			if (!this.data.isLoad) return;
			
			const tabHeightCache = this.data.tabHeightCache;
			if (!tabHeightCache || tabHeightCache.length === 0) return;

			const scrollTop = e.detail.scrollTop + 20;
			const scrollHeight = e.detail.scrollHeight;
			const clientHeight = wx.getSystemInfoSync().windowHeight;

			// 🔥 检测是否接近底部（提前300px触发加载）
			if (scrollTop + clientHeight > scrollHeight - 300) {
				if (this.data.hasMoreDays && !this.data.isLoadingMore) {
					this._loadMoreDays();
				}
			}

			// 更新当前tab
			for (let i = 0; i < tabHeightCache.length; i++) {
				if (scrollTop >= tabHeightCache[i].top && scrollTop < tabHeightCache[i].bottom) {
					if (this.data.tabCur !== i) {
						this.setData({
							verticalNavTop: (i - 1) * 50,
							tabCur: i
						});
					}
					break;
				}
			}
		},

		bindTabSelectTap: function (e) {
			let idx = pageHelper.dataset(e, 'idx');
			this.setData({
				tabCur: idx,
				mainCur: idx,
				verticalNavTop: (idx - 1) * 50
			})
		},

		bindShowMindTap: function (e) {
			if (this.data.showMind) return;
			
			this.setData({
				showMind: true,
				showTime: false
			});
		},

		bindShowTimeTap: function (e) {
			if (this.data.showTime) return;
			
			this.setData({
				showMind: false,
				showTime: true
			});
			
			if (!this.data.tabHeightCache || this.data.tabHeightCache.length === 0) {
				setTimeout(() => {
					this._calculateTabHeights();
				}, 100);
			}
		}
	}
})