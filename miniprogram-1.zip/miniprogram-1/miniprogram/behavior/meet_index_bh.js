/**
 * Notes: 预约列表页 Behavior - 添加预加载优化
 * Date: 2025-11-17
 */

const cloudHelper = require('../helper/cloud_helper.js');
const pageHelper = require('../helper/page_helper.js');
const setting = require('../setting/setting.js');
const MeetBiz = require('../biz/meet_biz.js');
const { PreloadManager } = require('../helper/preload_manager.js');

module.exports = Behavior({

	data: {
		isLoad: false,
		_params: {},
		
		dataList: {
			list: []
		},
		
		// 列表展示模式
		listMode: 'card',
		
		// 搜索关键词
		search: '',
		
		// 是否显示顶部图片
		showUp: false,
		upImg: '',
		
		// 是否显示总数菜单
		isTotalMenu: false,
		
		// 是否返回首页
		returnHome: false,
	},

	methods: {
		onLoad: function (options) {
			if (!pageHelper.getOptions(this, options)) return;
			
			// 设置搜索参数
			this._params = options;
		},

		onReady: function () {
			// 在 meet_index.js 中已处理
		},

		onShow: function () {
			
		},

		onHide: function () {
			
		},

		onUnload: function () {
			
		},

		onPullDownRefresh: async function () {
			// 通用列表组件会自动处理刷新
			wx.stopPullDownRefresh();
		},

		onReachBottom: function () {
			// 通用列表组件会自动处理分页
		},

		/**
		 * 🔥 列表加载完成回调 - 触发预加载
		 */
		bindCommListCmpt: function (e) {
			const dataList = e.detail;
			
			this.setData({
				dataList: dataList
			});

			// 🔥 关键：列表加载完成后，预加载前3个预约的详情
			if (dataList.list && dataList.list.length > 0) {
				this._preloadTopItems(dataList.list, 3);
			}
		},

		/**
		 * 🔥 预加载列表顶部的N个项目
		 */
		_preloadTopItems: function(list, count = 3) {
			if (!list || list.length === 0) return;
			
			const meetIds = list.slice(0, count).map(item => item._id).filter(id => id);
			
			if (meetIds.length > 0) {
				console.log(`[列表页] 准备预加载 ${meetIds.length} 个预约详情`);
				PreloadManager.preloadBatch(meetIds, count);
			}
		},

		/**
		 * 🔥 监听列表项点击 - 立即预加载
		 * 这个方法需要在 base_list_tpl.wxml 中绑定
		 */
		bindMeetItemTap: function(e) {
			const meetId = pageHelper.dataset(e, 'id');
			
			if (meetId) {
				// 🔥 立即预加载该项目（如果还没加载）
				PreloadManager.preloadDetail(meetId, true);
				
				console.log(`[列表页] 点击预约项，触发预加载: ${meetId}`);
			}
		},

		/**
		 * 🔥 智能预加载：监听列表滚动，预加载可见区域附近的项目
		 */
		onPageScroll: function(e) {
			// 节流：避免频繁触发
			if (this._scrollTimer) {
				clearTimeout(this._scrollTimer);
			}
			
			this._scrollTimer = setTimeout(() => {
				this._preloadVisibleItems(e.scrollTop);
			}, 500);
		},

		/**
		 * 预加载可见区域的项目
		 */
		_preloadVisibleItems: function(scrollTop) {
			const list = this.data.dataList.list;
			if (!list || list.length === 0) return;

			const query = wx.createSelectorQuery().in(this);
			query.selectAll('.meet-item').boundingClientRect();
			
			query.exec((res) => {
				if (!res || !res[0]) return;
				
				const items = res[0];
				const viewportHeight = wx.getSystemInfoSync().windowHeight;
				
				items.forEach((item, index) => {
					// 判断是否在可见区域附近（提前1屏预加载）
					const isNearVisible = item.top < viewportHeight * 2 && item.top > -viewportHeight;
					
					if (isNearVisible && list[index] && list[index]._id) {
						PreloadManager.preloadDetail(list[index]._id, true);
					}
				});
			});
		},

		/**
		 * 分享
		 */
		onShareAppMessage: function () {
			return {
				title: '预约列表',
				path: '/projects/A00/meet/index/meet_index'
			};
		},

		/**
		 * 设置类型标题（由 meet_index.js 调用）
		 */
		_setTypeTitle: function(skin) {
			wx.setNavigationBarTitle({
				title: skin.MEET_NAME + '列表'
			});
		}
	}
})